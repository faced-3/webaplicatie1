<?php 
    include ('./conn.php');
    header(header:'location: ../index.php');